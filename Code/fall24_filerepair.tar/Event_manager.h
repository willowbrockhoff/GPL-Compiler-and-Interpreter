/***

  Use this file and Event_manager.cpp w/o modification in p4.

  These files serve as a starting point for the Event_manager class in p5.

***/

#ifndef EVENT_MANAGER_H
#define EVENT_MANAGER_H

#include <memory>
#include <iostream>
#include <string>
#include <vector>

#include "Window.h" // for Keystroke enum

class Statement;

class Event_manager
{
  public:

    Event_manager();
    void execute_handlers(Window::Keystroke keystroke) const;
    void add_handler(Window::Keystroke, const Statement*);

    ~Event_manager();

    Event_manager(const Event_manager&) = delete; 
    const Event_manager &operator=(const Event_manager&) = delete;

};

#endif
